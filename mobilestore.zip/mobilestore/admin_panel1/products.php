<h2>Products</h2>
<a href="?con=prodcat" class="btn btn-info">Add Product</a>