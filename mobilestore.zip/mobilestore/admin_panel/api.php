
<?php
  include("config/database.php");
  //for del category
   if(isset($_POST['delcat']))
   {
       $cid=$_POST['delcat'];
       if(mysqli_query($con,"delete from category where id=$cid"))
       {
           echo "Category Deleted";
       }
       else
       {
           echo "Category not deleted";
       }
   }
?>
<?php
  include("config/database.php");
  //for del category
   if(isset($_POST['delpro']))
   {
       $pid=$_POST['delpro'];
       if(mysqli_query($con,"delete from product where id=$pid"))
       {
           echo "Product Deleted";
       }
       else
       {
           echo "Product not deleted";
       }
   }
?>