<?php
   $con=mysqli_connect("localhost","root","","10am_batch") or die("Not Connected");
?>